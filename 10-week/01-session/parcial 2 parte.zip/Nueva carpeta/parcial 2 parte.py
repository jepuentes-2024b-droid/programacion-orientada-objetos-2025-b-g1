from abc import ABC, abstractmethod

# ====================================================================
# 1. ENTIDADES BASE (entidades_base.py)
# ====================================================================

class Entidad(ABC):
    """Clase Abstracta que define la estructura general de cualquier entidad."""
    def __init__(self, id_unico: str):
        self._id_unico = id_unico

    def get_id(self) -> str:
        return self._id_unico

    @abstractmethod
    def mostrar_estado(self):
        pass

# --- Clase Base para Empleados ---

class Persona(Entidad, ABC):
    """Clase base abstracta para todos los empleados."""
    def __init__(self, id_empleado: str, nombre: str, disponible: bool = True):
        super().__init__(id_empleado)
        self.__nombre = nombre          
        self._disponible = disponible  

    def get_nombre(self) -> str:
        return self.__nombre

    def esta_disponible(self) -> bool:
        return self._disponible

    def set_disponibilidad(self, estado: bool):
        self._disponible = estado


# ====================================================================
# 2. EMPLEADOS (empleados.py)
# ====================================================================

class Conductor(Persona):
    """Empleado especializado en la conducción."""
    def __init__(self, id_empleado: str, nombre: str, tipo_licencia: str):
        super().__init__(id_empleado, nombre)
        self.__tipo_licencia = tipo_licencia

    def mostrar_estado(self):
        estado = "Disponible" if self.esta_disponible() else "En Ruta"
        print(f"| Conductor: {self.get_nombre()} (ID: {self.get_id()})")
        print(f"|    Licencia: {self.__tipo_licencia}, Estado: {estado}")


class Mecanico(Persona):
    """Empleado especializado en el mantenimiento de vehículos."""
    def __init__(self, id_empleado: str, nombre: str, especialidad: str):
        super().__init__(id_empleado, nombre, disponible=True)
        self.__especialidad = especialidad

    def realizar_mantenimiento(self, vehiculo):
        """Simula una interacción con el vehículo."""
        if self.esta_disponible():
            print(f"🔧 {self.get_nombre()} ({self.__especialidad}) inicia mantenimiento en {vehiculo.get_placa()}.")
            self.set_disponibilidad(False)
            vehiculo.recibir_mantenimiento()
            self.set_disponibilidad(True)
            print(f"✅ Mantenimiento finalizado en {vehiculo.get_placa()}.")
        else:
            print(f"❌ {self.get_nombre()} está ocupado en otro trabajo.")

    def mostrar_estado(self):
        estado = "Libre" if self.esta_disponible() else "Ocupado en taller"
        print(f"| Mecánico: {self.get_nombre()} (ID: {self.get_id()})")
        print(f"|    Especialidad: {self.__especialidad}, Estado: {estado}")


# ====================================================================
# 3. VEHÍCULOS (vehiculos.py)
# ====================================================================

class Vehiculo(Entidad, ABC):
    """Clase base abstracta para todos los vehículos."""
    def __init__(self, placa: str, capacidad_kg: float):
        super().__init__(placa)
        self.__placa = placa                
        self._capacidad_max = capacidad_kg  
        self.__kilometraje = 0              
        self._necesita_mant = False         
        self._conductor_asignado = None     

    def get_placa(self) -> str:
        return self.__placa

    def asignar_conductor(self, conductor: Conductor):
        if conductor and conductor.esta_disponible():
            self._conductor_asignado = conductor
            conductor.set_disponibilidad(False)
            print(f"     ⭐ Asignado: {conductor.get_nombre()} a {self.__placa}.")
        elif conductor:
            print(f"     ❌ ERROR: {conductor.get_nombre()} no está disponible.")
        else:
            if self._conductor_asignado:
                self._conductor_asignado.set_disponibilidad(True)
            self._conductor_asignado = None
            print(f"     🗑 Conductor desasignado de {self.__placa}.")

    def registrar_viaje(self, km: float):
        self.__kilometraje += km
        print(f"     ➡ {self.__placa} recorre {km} km.")
        if self.__kilometraje > 1000 and not self._necesita_mant:
            self._necesita_mant = True
            print(f"     🚨 ALERTA: {self.__placa} requiere mantenimiento.")

    @abstractmethod
    def recibir_mantenimiento(self):
        pass
    
    def _get_kilometraje(self):
        return self.__kilometraje


class Camioneta(Vehiculo):
    """Vehículo ligero."""
    def __init__(self, placa: str, capacidad_kg: float, tipo_traccion: str):
        super().__init__(placa, capacidad_kg)
        self.__tipo_traccion = tipo_traccion

    def recibir_mantenimiento(self):
        self._necesita_mant = False
        print(f"        ✅ Camioneta {self.get_placa()}: Servicio de aceite y revisión de tracción {self.__tipo_traccion}.")

    def mostrar_estado(self):
        conductor_nombre = self._conductor_asignado.get_nombre() if self._conductor_asignado else "N/A"
        mant = "SÍ" if self._necesita_mant else "NO"
        print(f"\n| VEHÍCULO: Camioneta ({self.get_placa()})")
        print(f"|    KM: {self._get_kilometraje()}, Mantenimiento Requerido: {mant}")


class Camion(Vehiculo):
    """Vehículo pesado."""
    def __init__(self, placa: str, capacidad_kg: float, tiene_trailer: bool):
        super().__init__(placa, capacidad_kg)
        self._tiene_trailer = tiene_trailer

    def recibir_mantenimiento(self):
        self._necesita_mant = False
        trailer = "y revisión de remolque" if self._tiene_trailer else ""
        print(f"        ✅ Camión {self.get_placa()}: Mantenimiento completo de motor {trailer}.")

    def mostrar_estado(self):
        conductor_nombre = self._conductor_asignado.get_nombre() if self._conductor_asignado else "N/A"
        mant = "SÍ" if self._necesita_mant else "NO"
        trailer = "Sí" if self._tiene_trailer else "No"
        print(f"\n| VEHÍCULO: Camión ({self.get_placa()})")
        print(f"|    Trailer: {trailer}, Mantenimiento Requerido: {mant}")


# ====================================================================
# 4. BLOQUE PRINCIPAL INTERACTIVO
# ====================================================================

FLOTA_VEHICULOS = []
PERSONAL = []

def crear_nuevo_vehiculo():
    print("\n--- CREACIÓN DE NUEVO VEHÍCULO ---")
    tipo = input("¿Qué tipo de vehículo desea crear? (Camioneta/Camion): ").strip().lower()
    placa = input("Ingrese la placa del vehículo (Ej: XYZ-123): ").strip().upper()
    
    try:
        capacidad = float(input("Ingrese la capacidad máxima de carga en KG: "))
        
        if tipo == 'camioneta':
            traccion = input("Tipo de tracción (Ej: 4x2, 4x4): ").strip()
            nuevo_vehiculo = Camioneta(placa, capacidad, traccion)
        elif tipo == 'camion':
            trailer_str = input("¿Tiene tráiler (remolque)? (s/n): ").strip().lower()
            tiene_trailer = (trailer_str == 's')
            nuevo_vehiculo = Camion(placa, capacidad, tiene_trailer)
        else:
            print("❌ Tipo de vehículo no reconocido.")
            return

        FLOTA_VEHICULOS.append(nuevo_vehiculo)
        print(f"🎉 Vehículo {placa} ({tipo.capitalize()}) agregado a la flota.")
    
    except ValueError:
        print("❌ Error: La capacidad debe ser un número válido.")
    except Exception as e:
        print(f"❌ Ocurrió un error inesperado: {e}")


def crear_nuevo_empleado():
    print("\n--- REGISTRO DE NUEVO EMPLEADO ---")
    rol = input("¿Qué rol de empleado desea registrar? (Conductor/Mecanico): ").strip().lower()
    nombre = input("Ingrese el nombre completo del empleado: ").strip()
    id_empleado = input("Ingrese el ID del empleado (Ej: E001): ").strip().upper()
    
    if any(p.get_id() == id_empleado for p in PERSONAL):
        print("❌ Error: Ya existe un empleado con ese ID.")
        return

    try:
        if rol == 'conductor':
            licencia = input("Tipo de licencia de conducción: ").strip()
            nuevo_empleado = Conductor(id_empleado, nombre, licencia)
        elif rol == 'mecanico':
            especialidad = input("Especialidad del mecánico (Ej: Diesel, Frenos): ").strip()
            nuevo_empleado = Mecanico(id_empleado, nombre, especialidad)
        else:
            print("❌ Rol de empleado no reconocido.")
            return

        PERSONAL.append(nuevo_empleado)
        print(f"🥳 Empleado {nombre} ({rol.capitalize()}) registrado con éxito.")
        
    except Exception as e:
        print(f"❌ Ocurrió un error inesperado: {e}")


def asignar_conductor_interactivo():
    if not [p for p in PERSONAL if isinstance(p, Conductor)]:
        print("⚠ No hay conductores registrados para asignar.")
        return
    if not FLOTA_VEHICULOS:
        print("⚠ No hay vehículos registrados.")
        return
        
    print("\n--- ASIGNACIÓN DE CONDUCTOR ---")
    
    conductores_disponibles = [p for p in PERSONAL if isinstance(p, Conductor) and p.esta_disponible()]
    if not conductores_disponibles:
        print("⚠ Todos los conductores están actualmente asignados o no hay conductores.")
        return
        
    print("\nConductores Disponibles:")
    for i, c in enumerate(conductores_disponibles):
        print(f"  [{i+1}] {c.get_nombre()} (ID: {c.get_id()})")

    vehiculos_sin_asignar = [v for v in FLOTA_VEHICULOS if v._conductor_asignado is None]
    if not vehiculos_sin_asignar:
        print("\n⚠ Todos los vehículos tienen un conductor asignado.")
        return
        
    print("\nVehículos sin asignar:")
    for i, v in enumerate(vehiculos_sin_asignar):
        print(f"  [{i+1}] {v.get_placa()} ({type(v).__name__})")
        
    try:
        idx_c = int(input("\nSeleccione el número del conductor a asignar: ")) - 1
        idx_v = int(input("Seleccione el número del vehículo a asignar: ")) - 1
        
        conductor_sel = conductores_disponibles[idx_c]
        vehiculo_sel = vehiculos_sin_asignar[idx_v]
        
        vehiculo_sel.asignar_conductor(conductor_sel)
        
    except (IndexError, ValueError):
        print("❌ Selección inválida. Por favor, ingrese un número de la lista.")


def simular_mantenimiento_interactivo():
    mecanicos_disponibles = [p for p in PERSONAL if isinstance(p, Mecanico) and p.esta_disponible()]
    vehiculos_con_mant = [v for v in FLOTA_VEHICULOS if v._necesita_mant]

    if not mecanicos_disponibles:
        print("⚠ No hay mecánicos disponibles para realizar el trabajo.")
        return
    if not vehiculos_con_mant:
        print("✅ Ningún vehículo requiere mantenimiento actualmente.")
        return
        
    print("\n--- SIMULACIÓN DE MANTENIMIENTO ---")
    print("Mecánicos Disponibles:")
    for i, m in enumerate(mecanicos_disponibles):
        print(f"  [{i+1}] {m.get_nombre()}")
    
    print("\nVehículos que NECESITAN MANTENIMIENTO:")
    for i, v in enumerate(vehiculos_con_mant):
        print(f"  [{i+1}] {v.get_placa()} ({type(v).__name__})")

    try:
        idx_m = int(input("\nSeleccione el número del mecánico: ")) - 1
        idx_v = int(input("Seleccione el número del vehículo a reparar: ")) - 1
        
        mecanico_sel = mecanicos_disponibles[idx_m]
        vehiculo_sel = vehiculos_con_mant[idx_v]
        
        mecanico_sel.realizar_mantenimiento(vehiculo_sel)
        
    except (IndexError, ValueError):
        print("❌ Selección inválida.")


def mostrar_estado_general():
    print("\n\n" + "="*50)
    print("         ESTADO ACTUAL DE LA EMPRESA")
    print("="*50)
    
    print("\n--- PERSONAL ---")
    if not PERSONAL:
        print("No hay personal registrado.")
    for p in PERSONAL:
        p.mostrar_estado()
    
    print("\n--- FLOTA DE VEHÍCULOS ---")
    if not FLOTA_VEHICULOS:
        print("No hay vehículos registrados.")
    for v in FLOTA_VEHICULOS:
        v.mostrar_estado()
    print("="*50)


# BLOQUE PRINCIPAL
if __name__ == "__main__":
    
    print("==============================================")
    print("      SISTEMA INTERACTIVO DE GESTIÓN (POO)      ")
    print("==============================================")
    
    PERSONAL.append(Conductor("C001", "Juan Pérez", "C2"))
    PERSONAL.append(Mecanico("M010", "Luis Sánchez", "Diesel"))
    FLOTA_VEHICULOS.append(Camioneta("ABC-123", 2000, "4x2"))
    FLOTA_VEHICULOS.append(Camion("XYZ-987", 25000, True))
    print("Datos de ejemplo cargados.")
    
    while True:
        print("\n\n--- MENÚ PRINCIPAL ---")
        print("1. Crear Nuevo Empleado")
        print("2. Crear Nuevo Vehículo")
        print("3. Asignar Conductor a Vehículo")
        print("4. Simular Viaje")
        print("5. Realizar Mantenimiento")
        print("6. Mostrar Estado General de la Empresa")
        print("0. Salir")
        
        opcion = input("Seleccione una opción: ").strip()
        
        if opcion == '1':
            crear_nuevo_empleado()
        elif opcion == '2':
            crear_nuevo_vehiculo()
        elif opcion == '3':
            asignar_conductor_interactivo()
        elif opcion == '4':
            if not FLOTA_VEHICULOS:
                print("⚠ No hay vehículos para simular viaje.")
                continue
            
            print("\nVehículos de la flota:")
            for i, v in enumerate(FLOTA_VEHICULOS):
                conductor = v._conductor_asignado.get_nombre() if v._conductor_asignado else "N/A"
                print(f"  [{i+1}] {v.get_placa()} (Conductor: {conductor})")
            
            try:
                idx = int(input("Seleccione el número del vehículo que viaja: ")) - 1
                km = float(input("Ingrese los KM recorridos en el viaje: "))
                FLOTA_VEHICULOS[idx].registrar_viaje(km)
            except (IndexError, ValueError):
                print("❌ Selección o KM inválidos.")
            except Exception as e:
                print(f"❌ Error al registrar viaje: {e}")
                
        elif opcion == '5':
            simular_mantenimiento_interactivo()
        elif opcion == '6':
            mostrar_estado_general()
        elif opcion == '0':
            print("Cerrando sistema. ¡Adiós!")
            break
        else:
            print("Opción no válida. Intente de nuevo.")
