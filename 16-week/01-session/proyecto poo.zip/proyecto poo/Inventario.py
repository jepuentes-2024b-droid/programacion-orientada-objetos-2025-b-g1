"""

Dependencias (instalar si falta):
- reportlab  -> pip install reportlab
- fpdf       -> pip install fpdf
- py --version
- py -m pip install --upgrade pip
- py -m pip install reportlab fpdf


"""

import json
import os
import datetime
from decimal import Decimal, InvalidOperation
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

# Intentar importar reportlab, si falla usar fpdf
USE_REPORTLAB = False
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas as rl_canvas
    USE_REPORTLAB = True
except Exception:
    try:
        from fpdf import FPDF
    except Exception:
        FPDF = None

DATA_INVENTARIO = "inventario.json"
DATA_VENTAS = "ventas.json"

# -------------------- Modelos --------------------
class Producto:
    def __init__(self, codigo, nombre, cantidad, precio_compra, precio_venta):
        self.codigo = str(codigo)
        self.nombre = nombre
        self.cantidad = int(cantidad)
        self.precio_compra = float(precio_compra)
        self.precio_venta = float(precio_venta)

    def to_dict(self):
        return {
            "codigo": self.codigo,
            "nombre": self.nombre,
            "cantidad": self.cantidad,
            "precio_compra": self.precio_compra,
            "precio_venta": self.precio_venta,
        }

    @staticmethod
    def from_dict(d):
        return Producto(d["codigo"], d["nombre"], d["cantidad"], d["precio_compra"], d["precio_venta"])

class Venta:
    def __init__(self, id_venta, fecha, items, total, cliente_name="Cliente", cliente_documento=""):
        # items: list of {codigo, nombre, cantidad, precio_unitario, precio_compra_unitario}
        self.id_venta = id_venta
        self.fecha = fecha
        self.items = items
        self.total = float(total)
        self.cliente_name = cliente_name
        self.cliente_documento = cliente_documento

    def to_dict(self):
        return {
            "id_venta": self.id_venta,
            "fecha": self.fecha.isoformat(),
            "items": self.items,
            "total": self.total,
            "cliente_name": self.cliente_name,
            "cliente_documento": self.cliente_documento,
        }

    @staticmethod
    def from_dict(d):
        fecha = datetime.datetime.fromisoformat(d["fecha"])
        return Venta(d["id_venta"], fecha, d["items"], d["total"], d.get("cliente_name", "Cliente"), d.get("cliente_documento", ""))

# -------------------- Repositorios --------------------
class Inventario:
    def __init__(self):
        self.productos = []

    def agregar(self, p: Producto):
        if self.buscar(p.codigo):
            raise ValueError("El código ya existe")
        self.productos.append(p)

    def listar(self):
        return self.productos

    def buscar(self, codigo):
        for p in self.productos:
            if p.codigo == str(codigo):
                return p
        return None

    def actualizar(self, codigo, **kwargs):
        p = self.buscar(codigo)
        if not p:
            raise ValueError("Producto no encontrado")
        p.nombre = kwargs.get("nombre", p.nombre)
        p.cantidad = int(kwargs.get("cantidad", p.cantidad))
        p.precio_compra = float(kwargs.get("precio_compra", p.precio_compra))
        p.precio_venta = float(kwargs.get("precio_venta", p.precio_venta))

    def eliminar(self, codigo):
        p = self.buscar(codigo)
        if p:
            self.productos.remove(p)

    def guardar(self, archivo=DATA_INVENTARIO):
        with open(archivo, "w", encoding="utf-8") as f:
            json.dump([p.to_dict() for p in self.productos], f, indent=4, ensure_ascii=False)

    def cargar(self, archivo=DATA_INVENTARIO):
        if not os.path.exists(archivo):
            self.productos = []
            return
        with open(archivo, "r", encoding="utf-8") as f:
            data = json.load(f)
            self.productos = [Producto.from_dict(d) for d in data]

class VentasRepo:
    def __init__(self):
        self.ventas = []

    def registrar_venta(self, venta: Venta):
        self.ventas.append(venta)

    def guardar(self, archivo=DATA_VENTAS):
        with open(archivo, "w", encoding="utf-8") as f:
            json.dump([v.to_dict() for v in self.ventas], f, indent=4, ensure_ascii=False)

    def cargar(self, archivo=DATA_VENTAS):
        if not os.path.exists(archivo):
            self.ventas = []
            return
        with open(archivo, "r", encoding="utf-8") as f:
            data = json.load(f)
            self.ventas = [Venta.from_dict(d) for d in data]

# -------------------- PDF / Factura --------------------

def generar_factura_pdf(venta: Venta, archivo_out):
    """Genera una factura PDF usando reportlab si está disponible, si no intenta con FPDF."""
    if USE_REPORTLAB:
        c = rl_canvas.Canvas(archivo_out, pagesize=A4)
        ancho, alto = A4
        margen = 50
        y = alto - margen

        c.setFont("Helvetica-Bold", 16)
        c.drawString(margen, y, "Factura - Playa Andina")
        c.setFont("Helvetica", 10)
        y -= 25
        c.drawString(margen, y, f"Factura #: {venta.id_venta}")
        c.drawString(margen + 300, y, f"Fecha: {venta.fecha.strftime('%Y-%m-%d %H:%M:%S')}")
        y -= 20
        c.drawString(margen, y, f"Cliente: {venta.cliente_name}")
        c.drawString(margen + 300, y, f"Documento: {venta.cliente_documento}")
        y -= 30

        c.setFont("Helvetica-Bold", 10)
        c.drawString(margen, y, "Código")
        c.drawString(margen + 70, y, "Nombre")
        c.drawString(margen + 300, y, "Cant.")
        c.drawString(margen + 350, y, "P.Unit")
        c.drawString(margen + 420, y, "Subtotal")
        y -= 15
        c.setFont("Helvetica", 10)

        for item in venta.items:
            subtotal = item['cantidad'] * item['precio_unitario']
            c.drawString(margen, y, str(item['codigo']))
            c.drawString(margen + 70, y, item['nombre'][:30])
            c.drawRightString(margen + 345, y, str(item['cantidad']))
            c.drawRightString(margen + 415, y, f"{item['precio_unitario']:.2f}")
            c.drawRightString(margen + 495, y, f"{subtotal:.2f}")
            y -= 15
            if y < 80:
                c.showPage()
                y = alto - margen

        y -= 10
        c.setFont("Helvetica-Bold", 12)
        c.drawRightString(margen + 495, y, f"Total: {venta.total:.2f}")
        c.save()
        return True
    else:
        if FPDF is None:
            raise RuntimeError("No está instalado reportlab ni fpdf. Instale al menos uno: pip install reportlab fpdf")
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", "B", 16)
        pdf.cell(0, 10, "Factura - Playa Andina", ln=True)
        pdf.set_font("Arial", size=10)
        pdf.cell(0, 8, f"Factura #: {venta.id_venta}", ln=True)
        pdf.cell(0, 8, f"Fecha: {venta.fecha.strftime('%Y-%m-%d %H:%M:%S')}", ln=True)
        pdf.cell(0, 8, f"Cliente: {venta.cliente_name}", ln=True)
        pdf.cell(0, 8, f"Documento: {venta.cliente_documento}", ln=True)
        pdf.ln(4)

        pdf.set_font("Arial", 'B', 10)
        pdf.cell(30, 8, "Codigo", 0)
        pdf.cell(80, 8, "Nombre", 0)
        pdf.cell(20, 8, "Cant.", 0, align='R')
        pdf.cell(30, 8, "P.Unit", 0, align='R')
        pdf.cell(30, 8, "Subtotal", 0, align='R')
        pdf.ln(8)
        pdf.set_font("Arial", size=10)
        for item in venta.items:
            subtotal = item['cantidad'] * item['precio_unitario']
            pdf.cell(30, 8, str(item['codigo']), 0)
            pdf.cell(80, 8, item['nombre'][:40], 0)
            pdf.cell(20, 8, str(item['cantidad']), 0, align='R')
            pdf.cell(30, 8, f"{item['precio_unitario']:.2f}", 0, align='R')
            pdf.cell(30, 8, f"{subtotal:.2f}", 0, align='R')
            pdf.ln(8)

        pdf.ln(4)
        pdf.set_font("Arial", 'B', 12)
        pdf.cell(0, 8, f"Total: {venta.total:.2f}", ln=True, align='R')
        pdf.output(archivo_out)
        return True

# -------------------- GUI --------------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Inventario Playa Andina")
        self.geometry("1000x600")

        self.inventario = Inventario()
        self.inventario.cargar()
        self.ventas_repo = VentasRepo()
        self.ventas_repo.cargar()

        self.create_widgets()
        self.refresh_product_tree()
        self.refresh_sales_tree()

    def create_widgets(self):
        # Notebook
        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True)

        # Tab Inventario
        frame_inv = ttk.Frame(nb)
        nb.add(frame_inv, text='Inventario')

        # Product form
        form = ttk.Frame(frame_inv)
        form.pack(side='top', fill='x', padx=10, pady=10)

        labels = ['Codigo', 'Nombre', 'Cantidad', 'Precio Compra', 'Precio Venta']
        self.entries = {}
        for i, lab in enumerate(labels):
            ttk.Label(form, text=lab).grid(row=0, column=i*2, sticky='w')
            e = ttk.Entry(form, width=18)
            e.grid(row=0, column=i*2+1, padx=5)
            self.entries[lab] = e

        ttk.Button(form, text='Agregar', command=self.add_product).grid(row=0, column=11, padx=5)
        ttk.Button(form, text='Actualizar', command=self.update_product).grid(row=0, column=12, padx=5)
        ttk.Button(form, text='Eliminar', command=self.delete_product).grid(row=0, column=13, padx=5)
        ttk.Button(form, text='Guardar', command=self.save_data).grid(row=0, column=14, padx=5)

        # Treeview productos
        cols = ('codigo', 'nombre', 'cantidad', 'precio_compra', 'precio_venta')
        self.tree_products = ttk.Treeview(frame_inv, columns=cols, show='headings')
        for c in cols:
            self.tree_products.heading(c, text=c.capitalize())
            self.tree_products.column(c, width=140)
        self.tree_products.pack(fill='both', expand=True, padx=10, pady=10)
        self.tree_products.bind('<<TreeviewSelect>>', self.on_product_select)

        # Tab Ventas
        frame_sales = ttk.Frame(nb)
        nb.add(frame_sales, text='Ventas')

        sales_top = ttk.Frame(frame_sales)
        sales_top.pack(side='top', fill='x', padx=10, pady=10)
        ttk.Label(sales_top, text='Cliente').grid(row=0, column=0)
        self.entry_cliente = ttk.Entry(sales_top)
        self.entry_cliente.grid(row=0, column=1, padx=5)

        ttk.Label(sales_top, text='Documento').grid(row=0, column=2)
        self.entry_cliente_doc = ttk.Entry(sales_top)
        self.entry_cliente_doc.grid(row=0, column=3, padx=5)

        ttk.Label(sales_top, text='Producto (código)').grid(row=0, column=4)
        self.entry_venta_codigo = ttk.Entry(sales_top)
        self.entry_venta_codigo.grid(row=0, column=5, padx=5)

        ttk.Label(sales_top, text='Cantidad').grid(row=0, column=6)
        self.entry_venta_cant = ttk.Entry(sales_top, width=8)
        self.entry_venta_cant.grid(row=0, column=7, padx=5)

        ttk.Button(sales_top, text='Agregar a venta', command=self.add_item_to_cart).grid(row=0, column=8, padx=5)
        ttk.Button(sales_top, text='Realizar venta', command=self.checkout).grid(row=0, column=9, padx=5)
        ttk.Button(sales_top, text='Factura PDF', command=self.generate_selected_invoice).grid(row=0, column=10, padx=5)

        # Cart tree
        cart_cols = ('codigo', 'nombre', 'cantidad', 'precio_unitario', 'subtotal')
        self.tree_cart = ttk.Treeview(frame_sales, columns=cart_cols, show='headings', height=6)
        for c in cart_cols:
            self.tree_cart.heading(c, text=c.capitalize())
            self.tree_cart.column(c, width=150)
        self.tree_cart.pack(fill='x', padx=10, pady=5)

        ttk.Button(frame_sales, text='Quitar seleccionado', command=self.remove_from_cart).pack(padx=10, pady=5)

        # Sales history
        sales_hist_cols = ('id', 'fecha', 'cliente', 'total')
        self.tree_sales = ttk.Treeview(frame_sales, columns=sales_hist_cols, show='headings')
        for c in sales_hist_cols:
            self.tree_sales.heading(c, text=c.capitalize())
            self.tree_sales.column(c, width=200)
        self.tree_sales.pack(fill='both', expand=True, padx=10, pady=10)
        self.tree_sales.bind('<<TreeviewSelect>>', self.on_sale_select)

        # Tab Reportes
        frame_reports = ttk.Frame(nb)
        nb.add(frame_reports, text='Reportes')

        btns = ttk.Frame(frame_reports)
        btns.pack(side='top', fill='x', padx=10, pady=10)
        ttk.Button(btns, text='Generar reporte de ventas', command=self.generate_sales_report).pack(side='left', padx=5)
        ttk.Button(btns, text='Exportar reporte CSV', command=self.export_report_csv).pack(side='left', padx=5)

        self.txt_report = tk.Text(frame_reports, height=20)
        self.txt_report.pack(fill='both', expand=True, padx=10, pady=10)

    # ---------------- Product actions ----------------
    def add_product(self):
        try:
            codigo = self.entries['Codigo'].get().strip()
            nombre = self.entries['Nombre'].get().strip()
            cantidad = int(self.entries['Cantidad'].get().strip())
            precio_compra = float(self.entries['Precio Compra'].get().strip())
            precio_venta = float(self.entries['Precio Venta'].get().strip())
            if not codigo or not nombre:
                messagebox.showwarning('Datos incompletos', 'Codigo y nombre son obligatorios')
                return
            p = Producto(codigo, nombre, cantidad, precio_compra, precio_venta)
            self.inventario.agregar(p)
            self.refresh_product_tree()
            self.clear_form()
        except ValueError as e:
            messagebox.showerror('Error', str(e))
        except Exception as e:
            messagebox.showerror('Error', f'Error al agregar producto: {e}')

    def update_product(self):
        try:
            codigo = self.entries['Codigo'].get().strip()
            if not codigo:
                messagebox.showwarning('Código requerido', 'Ingrese el código del producto a actualizar')
                return
            kwargs = {}
            if self.entries['Nombre'].get().strip():
                kwargs['nombre'] = self.entries['Nombre'].get().strip()
            if self.entries['Cantidad'].get().strip():
                kwargs['cantidad'] = int(self.entries['Cantidad'].get().strip())
            if self.entries['Precio Compra'].get().strip():
                kwargs['precio_compra'] = float(self.entries['Precio Compra'].get().strip())
            if self.entries['Precio Venta'].get().strip():
                kwargs['precio_venta'] = float(self.entries['Precio Venta'].get().strip())
            self.inventario.actualizar(codigo, **kwargs)
            self.refresh_product_tree()
            self.clear_form()
        except Exception as e:
            messagebox.showerror('Error', f'Error al actualizar: {e}')

    def delete_product(self):
        codigo = self.entries['Codigo'].get().strip()
        if not codigo:
            messagebox.showwarning('Código requerido', 'Ingrese el código del producto a eliminar')
            return
        self.inventario.eliminar(codigo)
        self.refresh_product_tree()
        self.clear_form()

    def clear_form(self):
        for e in self.entries.values():
            e.delete(0, tk.END)

    def on_product_select(self, event):
        sel = self.tree_products.selection()
        if not sel:
            return
        vals = self.tree_products.item(sel[0], 'values')
        # (codigo, nombre, cantidad, precio_compra, precio_venta)
        keys = ['Codigo', 'Nombre', 'Cantidad', 'Precio Compra', 'Precio Venta']
        for k, v in zip(keys, vals):
            self.entries[k].delete(0, tk.END)
            self.entries[k].insert(0, v)

    def refresh_product_tree(self):
        for r in self.tree_products.get_children():
            self.tree_products.delete(r)
        for p in self.inventario.listar():
            self.tree_products.insert('', tk.END, values=(p.codigo, p.nombre, p.cantidad, f"{p.precio_compra:.2f}", f"{p.precio_venta:.2f}"))

    def save_data(self):
        self.inventario.guardar()
        self.ventas_repo.guardar()
        messagebox.showinfo('Guardado', 'Inventario y ventas guardados en disco')

    # ---------------- Sales actions ----------------
    def add_item_to_cart(self):
        codigo = self.entry_venta_codigo.get().strip()
        if not codigo:
            messagebox.showwarning('Código requerido', 'Ingrese un código de producto')
            return
        p = self.inventario.buscar(codigo)
        if not p:
            messagebox.showerror('No encontrado', 'Producto no existe')
            return
        try:
            qty = int(self.entry_venta_cant.get().strip())
        except Exception:
            messagebox.showerror('Cantidad inválida', 'Ingrese una cantidad válida')
            return
        if qty <= 0:
            messagebox.showerror('Cantidad inválida', 'La cantidad debe ser mayor a 0')
            return
        if qty > p.cantidad:
            messagebox.showerror('Stock insuficiente', f"Stock disponible: {p.cantidad}")
            return

        subtotal = qty * p.precio_venta
        self.tree_cart.insert('', tk.END, values=(p.codigo, p.nombre, qty, f"{p.precio_venta:.2f}", f"{subtotal:.2f}"))
        # limpiar campos
        self.entry_venta_codigo.delete(0, tk.END)
        self.entry_venta_cant.delete(0, tk.END)

    def remove_from_cart(self):
        sel = self.tree_cart.selection()
        for s in sel:
            self.tree_cart.delete(s)

    def checkout(self):
        items = []
        total = 0.0
        for row in self.tree_cart.get_children():
            codigo, nombre, cantidad, precio_unitario, subtotal = self.tree_cart.item(row, 'values')
            cantidad = int(cantidad)
            precio_unitario = float(precio_unitario)
            subtotal = float(subtotal)
            p = self.inventario.buscar(codigo)
            if not p:
                messagebox.showerror('Error', f'Producto {codigo} no encontrado en inventario')
                return
            if cantidad > p.cantidad:
                messagebox.showerror('Error', f'Stock insuficiente para {codigo}')
                return
            items.append({
                'codigo': codigo,
                'nombre': nombre,
                'cantidad': cantidad,
                'precio_unitario': precio_unitario,
                'precio_compra_unitario': p.precio_compra,
            })
            total += subtotal

        if not items:
            messagebox.showwarning('Carrito vacío', 'Agregue items antes de realizar la venta')
            return

        cliente = self.entry_cliente.get().strip() or 'Cliente'
        doc = self.entry_cliente_doc.get().strip()
        id_venta = f"V-{len(self.ventas_repo.ventas)+1:06d}"
        fecha = datetime.datetime.now()
        venta = Venta(id_venta, fecha, items, total, cliente, doc)
        # descontar stock
        for it in items:
            p = self.inventario.buscar(it['codigo'])
            p.cantidad -= it['cantidad']

        self.ventas_repo.registrar_venta(venta)
        self.inventario.guardar()
        self.ventas_repo.guardar()
        self.refresh_product_tree()
        self.refresh_sales_tree()
        # limpiar carrito
        for r in self.tree_cart.get_children():
            self.tree_cart.delete(r)
        messagebox.showinfo('Venta realizada', f'Venta registrada. ID: {venta.id_venta}')

    def refresh_sales_tree(self):
        for r in self.tree_sales.get_children():
            self.tree_sales.delete(r)
        for v in self.ventas_repo.ventas:
            self.tree_sales.insert('', tk.END, values=(v.id_venta, v.fecha.strftime('%Y-%m-%d %H:%M:%S'), v.cliente_name, f"{v.total:.2f}"))

    def on_sale_select(self, event):
        pass

    def generate_selected_invoice(self):
        sel = self.tree_sales.selection()
        if not sel:
            messagebox.showwarning('Seleccione venta', 'Seleccione una venta en el historial para generar factura')
            return
        vals = self.tree_sales.item(sel[0], 'values')
        id_venta = vals[0]
        venta = next((v for v in self.ventas_repo.ventas if v.id_venta == id_venta), None)
        if not venta:
            messagebox.showerror('Error', 'Venta no encontrada')
            return
        if not getattr(venta, 'cliente_documento', ''):
            doc = simpledialog.askstring('Documento', 'Ingrese el documento del cliente')
            if not doc:
                return
            venta.cliente_documento = doc
            self.ventas_repo.guardar()
        destino = filedialog.asksaveasfilename(defaultextension='.pdf', filetypes=[('PDF','*.pdf')], initialfile=f"factura_{venta.id_venta}.pdf")
        if not destino:
            return
        try:
            generar_factura_pdf(venta, destino)
            messagebox.showinfo('Factura creada', f'Factura creada: {destino}')
        except Exception as e:
            messagebox.showerror('Error', f'No se pudo generar la factura: {e}')

    # ---------------- Reports ----------------
    def generate_sales_report(self):
        total_ingresos = 0.0
        total_costos = 0.0
        total_ganancia = 0.0
        detalle = []
        for v in self.ventas_repo.ventas:
            for it in v.items:
                ingresos = it['precio_unitario'] * it['cantidad']
                costo = it['precio_compra_unitario'] * it['cantidad']
                gan = ingresos - costo
                total_ingresos += ingresos
                total_costos += costo
                total_ganancia += gan
                detalle.append((v.id_venta, v.fecha.strftime('%Y-%m-%d'), it['codigo'], it['nombre'], it['cantidad'], it['precio_unitario'], it['precio_compra_unitario'], ingresos, costo, gan))

        out = []
        out.append(f"Reporte de ventas - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        out.append(f"Total ingresos: {total_ingresos:.2f}")
        out.append(f"Total costo: {total_costos:.2f}")
        out.append(f"Total ganancia: {total_ganancia:.2f}")
        out.append('\nDetalle por item:')
        out.append('ID | Fecha | Codigo | Nombre | Cant | P.Unit | C.Unit | Ingresos | Costos | Ganancia')
        for d in detalle:
            out.append(' | '.join([str(x) for x in d]))

        self.txt_report.delete('1.0', tk.END)
        self.txt_report.insert(tk.END, '\n'.join(out))

    def export_report_csv(self):
        # generar mismo detalle y exportar csv
        import csv
        destino = filedialog.asksaveasfilename(defaultextension='.csv', filetypes=[('CSV','*.csv')], initialfile='reporte_ventas.csv')
        if not destino:
            return
        rows = []
        for v in self.ventas_repo.ventas:
            for it in v.items:
                ingresos = it['precio_unitario'] * it['cantidad']
                costo = it['precio_compra_unitario'] * it['cantidad']
                gan = ingresos - costo
                rows.append({
                    'id_venta': v.id_venta,
                    'fecha': v.fecha.isoformat(),
                    'codigo': it['codigo'],
                    'nombre': it['nombre'],
                    'cantidad': it['cantidad'],
                    'precio_unitario': it['precio_unitario'],
                    'precio_compra_unitario': it['precio_compra_unitario'],
                    'ingresos': ingresos,
                    'costos': costo,
                    'ganancia': gan,
                })
        keys = ['id_venta','fecha','codigo','nombre','cantidad','precio_unitario','precio_compra_unitario','ingresos','costos','ganancia']
        with open(destino, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            for r in rows:
                writer.writerow(r)
        messagebox.showinfo('Exportado', f'Reporte exportado a {destino}')

# -------------------- Ejecutar --------------------
if __name__ == '__main__':
    app = App()
    app.mainloop()
